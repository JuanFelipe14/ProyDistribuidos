package controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClienteControler {
    public List<String> getLibrosCliente()  {
        Scanner in = null;
        try {
            in = new Scanner(new File("C:\\Users\\juanf\\OneDrive - Pontificia Universidad Javeriana\\Desktop\\TallerRMI\\Cliente\\Cliente\\src\\main\\resources\\libros.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        List<String> libros = new ArrayList<>();
        while (in.hasNextLine()){
            String isbn = in.next();
            libros.add(isbn);
        }
        return libros;
    }
}
