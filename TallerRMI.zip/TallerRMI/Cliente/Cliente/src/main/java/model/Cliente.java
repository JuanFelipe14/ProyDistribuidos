package model;

import org.example.OperacionesInterface;
import controller.ClienteControler;

import javax.swing.*;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @Nombre: Cliente.
 * @desc: Es el responsable de invocar metodos remotos en el servidor y obtener resultados haciendo uso del stub del objeto remoto para comunicarse con el servidor y procesar resultados devueltos.
 * @Autores: William D. Martinez, Paula A. Peñuela y Juan Felipe Arias.
 */
public class Cliente {

    private static OperacionesInterface look_up;  /* Creamos referencia al objeto remoto en el servidor. */

    public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {

        ClienteControler clienteControler= new ClienteControler();

        List<String> librosCliente = new ArrayList<>();

        librosCliente=clienteControler.getLibrosCliente();

        /*  Buscamos el objeto remoto con el nombre "MyServer" en la dirección IP "25.61.242.136" a través del servicio de registro RMI. */
        look_up = (OperacionesInterface) Naming.lookup("//localhost/MyServer");

        String[] opciones = {"Opcion 1", "Opcion 2", "Opcion 3", "Salir"}; /* Lista de opciones para menu de cliente. */

        int res = 0;

        /* De la linea 31 - 77 comprende el funcionamiento del menu de cliente */

        do {

            /* Creamos cuadros de dialogo para obtener la entrada del cliente. */
            res = JOptionPane.showOptionDialog(null, "Seleccione una opcion \n 1. Pedir libro. \n 2. Renovar libro. \n 3. Devolver libro. \n 4. Salir. ", "Menu de opciones", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
            String idLibro;
            String nombreLibro;

            switch (res) {
                case 0:
                    nombreLibro = JOptionPane.showInputDialog("Ingrese el titulo del libro");

                    /* Invocamos un metodo en un objeto remoto del servidor y almacenamos en la variable nombre. */
                    boolean resultadoPedir= look_up.pedirLibro(nombreLibro);
                    /* Mostramos resultado en cuadro de texto. */
                    JOptionPane.showMessageDialog(null, resultadoPedir);
                    break;
                case 1:
                    Object selection = JOptionPane.showInputDialog(null, "Choose now...","The Choice of a Lifetime", JOptionPane.QUESTION_MESSAGE, null,  librosCliente.toArray(), librosCliente.get(0));
                    idLibro =  selection.toString();
                    /* Invocamos un metodo en un objeto remoto del servidor y almacenamos en la variable promedioId. */
                    boolean resultadoRenovar = look_up.renovarLibro(idLibro);
                    /* Mostramos resultado en cuadro de texto. */
                    JOptionPane.showMessageDialog(null, "ID: " + idLibro);
                    break;
                case 2:
                    Object selectionDevolver = JOptionPane.showInputDialog(null, "Choose now...","The Choice of a Lifetime", JOptionPane.QUESTION_MESSAGE, null,  librosCliente.toArray(), librosCliente.get(0));
                    idLibro =  selectionDevolver.toString();
                    /* Invocamos un metodo en un objeto remoto del servidor y almacenamos en la variable promedioId. */
                    boolean resultadoDevolver = look_up.devolverLibro(idLibro);
                    /* Mostramos resultado en cuadro de texto. */
                    JOptionPane.showMessageDialog(null, "ID: " + idLibro);
                    break;
                case 3:

                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Adios!"); /* Salimos del menu.*/
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opcion Invalida."); /* Opcion Invalida. */
                    break;
            }
        } while (res != 5); /* Condicion */

    }
}
