package org.example;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<Integer> A = new ArrayList<>();
        List<Integer> numeros = new ArrayList<>();
        A.add(-7);
        A.add(12);
        A.add(-7);
        A.add(0);
        A.add(14);
        A.add(-7);
        A.add(5);

        subsecuenciaProductoMaximo_rec(A,numeros,0,0);

    }

    public List<Integer> subsecuenciaProductoMaximo_rec(List<Integer> A, List<Integer> numeros, int i, int resultado){

        if(i > A.size()){
            return numeros;
        }

        if(resultado == 0){
            return numeros;
        }

        if(i == 0){
            numeros.add(A.get(i).intValue());
            List<Integer> res = subsecuenciaProductoMaximo_rec(A,numeros,i+1,A.get(i).intValue());
            if(!res.isEmpty() || res != null){
                return res;
            }

        }else{
            int multiplicacion = resultado * A.get(i).intValue();

            if(multiplicacion < 0 && A.get(i).intValue() < 0){ /* Si ambos valores son negativos */

                if(multiplicacion > resultado){
                    numeros.add(A.get(i).intValue());
                }else{
                    return numeros;
                }
            }

            if(resultado > multiplicacion){
                return numeros;
            }else{
                numeros.add(A.get(i).intValue());
            }
        }

        return null;
    }

}


