package org.example.Server;

import org.example.Model.Libro;
import org.example.OperacionesInterface;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

/**
 * @Nombre: Servidor.
 * @desc: Esta clase servidor actúa como un intermediario entre los clientes y los objetos remotos, y permite a los clientes acceder a los métodos remotos definidos en la clase.
 * @Autores: William D. Martinez, Paula A. Peñuela y Juan Felipe Arias.
 * @required: Heredar de UnicastRemoteObject e implementar la interfaz OperacionesInterface.
 */

public class Servidor extends UnicastRemoteObject implements OperacionesInterface {

    public static ArrayList<Libro> listaLibros = new ArrayList<>();      /* Declarar lista de los libros.*/

    /**
     * @Nombre: Servidor.
     * @desc: Es un constructor que se inicializa para la clase "Servidor"y asegurar que la inicialización de la clase padre
     *        RemoteException tambien se realice correctamente.
     * @throws: RemoteException - Si ha ocurrido un error en una llamada a un metodo remoto de RMI.
     */
    protected Servidor() throws RemoteException {
        super();
    }

    public static void main(String[] args) {

        try (ZContext context = new ZContext()){

            Naming.rebind("//localhost/MyServer", new Servidor());     /* Registrar el servidor en registry con una direccion especifica. */
            System.out.println("Servidor listo!");

            ZMQ.Socket subscriber = context.createSocket(SocketType.SUB);
            subscriber.connect("tcp://localhost:5564");
            System.out.println("Nos conectamos!");

            if(args.length != 1){            /* Garantizamos que se reciba el numero correcto de argumentos. */
                System.out.println("Debe proporcionar el nombre del archivo como argumento.");    /* Caso de fracaso. */
                return;
            }

            String nombreArchivo = args[0];    /* Capturamos el nombre del archivo o ruta del archivo. */

            try {
                Scanner scanner = new Scanner(new File("C:\\Users\\juanf\\OneDrive - Pontificia Universidad Javeriana\\Desktop\\TallerRMI\\Servidor\\src\\main\\resources\\Libros.txt")); /* Creamos el archivo. */

                while(scanner.hasNextLine()){    /* Recorremos el archivo */
                    String linea = scanner.nextLine().trim();
                    String[] campos = linea.split("\\\\"); /* Delimitamos el archivo por comas. */
                    int id, cantidad;
                    String nombreLibro;

                    /* De la linea 63 a la 71 capturamos la informacion de los libros. */
                    id = Integer.parseInt(campos[0]);
                    System.out.println("id: " + id);
                    nombreLibro = campos[1];
                    System.out.println("nombreLibro:" + nombreLibro);
                    cantidad = Integer.parseInt(campos[2]);
                    System.out.println("cantidad: " + cantidad);

                    listaLibros.add(new Libro(id,nombreLibro,cantidad)); /* Instanciamos un libro con la informacion recibida y guardamos en la lista. */
                }

                scanner.close();  /* Cerramos Scanner */

            } catch (FileNotFoundException e) {  /* Si no encontrabamos el archivo. */
                throw new RuntimeException(e);
            }

        } catch (MalformedURLException e) {  /* Si el URL no existe o no se encuentra. */
            throw new RuntimeException(e);
        } catch (RemoteException e) {   /* Si hay un error en la llamada de un metodo remoto. */
            throw new RuntimeException(e);
        }
    }


    /**
     * @Nombre: pedirLibro.
     * @desc: Implementa un metodo remoto que retorna el nombre y apellido de un libro correspondiente a un ID proporcionado.
     * @param isbn Identificador.
     * @return String - Nombre completo libro.
     * @throws: RemoteException - Si ha ocurrido un error en una llamada a un metodo remoto de RMI.
     */

    @Override
    public Boolean pedirLibro(String isbn) throws RemoteException {

        if(!listaLibros.isEmpty()){
            for(Libro libro : listaLibros){
                if(Objects.equals(libro.getNombreLibro(), isbn)){
                    System.out.println(libro.getNombreLibro());
                    return true;
                }
            }
        }else{
            System.out.println("El archivo esta vacio.");
        }

        return false;
    }

    /**
     * @Nombre: renovarLibro.
     * @desc: Implementa un metodo remoto que retorna el promedio de un libro correspondiente a un ID proporcionado.
     * @param isbn Identificador estudiantil.
     * @return Float - promedio estudiantil.
     * @throws: RemoteException - Si ha ocurrido un error en una llamada a un metodo remoto de RMI.
     */

    @Override
    public Boolean renovarLibro(String isbn) throws RemoteException {
        System.out.println("Renovar Libro");

        if(!listaLibros.isEmpty()){
            for(Libro libro : listaLibros){
                if(Objects.equals(libro.getNombreLibro(), isbn)){
                    System.out.println(libro.getNombreLibro());
                    return true;
                }
            }
        }else{
            System.out.println("El archivo esta vacio.");
        }

        return false;
    }

    /**
     * @Nombre: devolverLibro.
     * @desc: Implementa un metodo remoto que retorna el promedio de un libro correspondiente a un nombre proporcionado.
     * @param isbn Nombre de libro.
     * @return Float - promedio estudiantil.
     * @throws: RemoteException - Si ha ocurrido un error en una llamada a un metodo remoto de RMI.
     */

    @Override
    public Boolean devolverLibro(String isbn) throws RemoteException {
        System.out.println("Devolver libro.");

        if(!listaLibros.isEmpty()){
            for(Libro libro : listaLibros){
                if(Objects.equals(libro.getNombreLibro(), isbn)){
                    System.out.println(libro.getNombreLibro());
                    return true;
                }
            }
        }else{
            System.out.println("El archivo esta vacio.");
        }

        return false;
    }

}