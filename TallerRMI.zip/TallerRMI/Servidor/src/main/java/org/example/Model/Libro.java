package org.example.Model;

import java.io.Serializable;
import java.util.ArrayList;

public class Libro implements Serializable {

    private int id;

    private String nombreLibro;

    private int cantidad;

    public Libro() {
    }

    public Libro(int id, String nombreLibro, int cantidad) {
        this.id = id;
        this.nombreLibro = nombreLibro;
        this.cantidad = cantidad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreLibro() {
        return nombreLibro;
    }

    public void setNombreLibro(String nombreLibro) {
        this.nombreLibro = nombreLibro;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
