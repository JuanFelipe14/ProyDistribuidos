package org.example;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;


/**
 * @desc Esta interfaz declara los metodos de la busqueda de información de los estudiantes.
 * @Autores William D. Martinez, Paula A. Peñuela y Juan Felipe Arias.
 * @required Heredar de Remote.
 */
public interface OperacionesInterface extends Remote {

    /**
     * @desc Este metodo obtiene el nombre de un estudiante dado un id estudiantil.
     * @param isbn - Identificador estudiante.
     * @return String - Nombre del estudiante.
     */
    public Boolean pedirLibro(String isbn) throws RemoteException;

    /**
     * @desc Este metodo calcula el promedio de un estudiante dado un id estudiantil.
     * @param isbn - Identificador estudiante.
     * @return Float - Promedio de estudiante.
     */
    public Boolean renovarLibro(String isbn) throws RemoteException;

    /**
     * @desc Este metodo calcula el promedio de un estudiante dado el nombre de estudiante.
     * @param isbn - El nombre de un estudiante.
     * @return Float - Promedio de estudiante.
     */
    public Boolean devolverLibro(String isbn) throws RemoteException;

}