												README

Autores: William D. Martinez, Paula A. Peñuela y Juan Felipe Arias.

Este es un sistema cliente-servidor que utiliza la tecnología RMI para proporcionar servicios de búsqueda de información de estudiantes. El servidor RMI mantiene una estructura de datos interna que contiene información de los estudiantes y proporciona métodos remotos para buscar información en función de diferentes criterios. El cliente RMI se conecta al servidor y proporciona un menú de opciones para que el usuario pueda elegir el servicio que desea utilizar. El sistema maneja excepciones de tipo RemoteException para errores de comunicación entre el cliente y el servidor.

El sistema utiliza excepciones de tipo RemoteException para manejar errores que pueden ocurrir durante la comunicación entre el cliente y el servidor.

Para ejecutar el servidor, se deben seguir los siguientes pasos en la línea de comandos de Windows:

1. Abrir una terminal de comandos de Windows.
2. Navegar hasta el directorio "misclasses" ya que ahí se encuentra el archivo Servidor.java.
3. Crear un registry con el siguiente comando:

	- start rmiregistry

4. Ejecutar el servidor con el siguiente comando.

	- java org.example.Server.Servidor "org\example\Server\estudiantes.txt"

Una vez ejecutado el servidor, se puede proceder a ejecutar el cliente. Puede correr el cliente desde un IDE sin ningún problema.

Recomendación: Utilizar IntelliJ.


